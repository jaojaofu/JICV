
import React, { useState } from 'react';
import { CalculationResult, Language } from '../types';
import { TRANSLATIONS } from '../constants';

interface CalculatorProps {
  onSave: (result: CalculationResult) => void;
  lang: Language;
}

const Calculator: React.FC<CalculatorProps> = ({ onSave, lang }) => {
  const t = TRANSLATIONS[lang];
  const [inputHeight, setInputHeight] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [results, setResults] = useState<{
    target: { cm: number; kg: number };
    acid: { cm: number; kg: number };
    water: { cm: number; kg: number };
  } | null>(null);

  const handleCalculate = () => {
    const h = parseFloat(inputHeight);
    setError(null);

    if (isNaN(h)) {
      setError(t.error_nan);
      return;
    }

    if (h < 1) {
      setError(t.error_low);
      setResults(null);
      return;
    }

    if (h > 175) {
      setError(t.error_high);
      setResults(null);
      return;
    }

    const BASE_VOLUME_PER_CM = 3.14 * 5.79;
    const totalVolume = h * BASE_VOLUME_PER_CM;
    
    // Tỷ trọng ở 20°C (kg/lít)
    const DENSITY_6 = 1.038;
    const DENSITY_60 = 1.498;
    const DENSITY_WATER = 1.0;

    const totalKg = totalVolume * DENSITY_6;
    const acidKg = totalKg * 0.1; // 6% / 60% = 0.1
    const waterKg = totalKg - acidKg;

    const roundedTotalKg = Math.round(totalKg);
    const roundedWaterKg = Math.round(waterKg);
    const roundedAcidKg = Math.round(acidKg);

    const totalCm = Number(h.toFixed(1));
    const acidCm = Number((acidKg / DENSITY_60 / BASE_VOLUME_PER_CM).toFixed(1));
    const waterCm = Number((waterKg / DENSITY_WATER / BASE_VOLUME_PER_CM).toFixed(1));

    const newResults = {
      target: { cm: totalCm, kg: roundedTotalKg },
      acid: { cm: acidCm, kg: roundedAcidKg },
      water: { cm: waterCm, kg: roundedWaterKg }
    };

    setResults(newResults);

    const record: CalculationResult = {
      id: crypto.randomUUID(),
      timestamp: Date.now(),
      batchName: `${t.batch_name} ${totalCm.toFixed(1)}cm`,
      targetVolume: roundedTotalKg,
      sourceConcentration: 60,
      targetConcentration: 6,
      acidVolumeNeeded: roundedAcidKg,
      waterVolumeNeeded: roundedWaterKg,
      checklistCompleted: false
    };
    onSave(record);
  };

  return (
    <div className="space-y-6">
      <div className="bg-[#efe9f4] rounded-[2rem] p-8 shadow-xl text-center border border-white/60 relative">
        <h2 className="text-[#5a5a5a] text-sm font-bold uppercase mb-6 tracking-tight">
          {lang === 'vi' ? 'Chiều cao rỗng bồn axit 6%' : '6% 硫酸タンクの空き容量'}
        </h2>
        
        <div className="relative mb-4">
          <input
            type="number"
            step="0.1"
            value={inputHeight}
            onChange={(e) => {
              setInputHeight(e.target.value);
              if (error) setError(null);
            }}
            onKeyDown={(e) => e.key === 'Enter' && handleCalculate()}
            placeholder={t.input_placeholder}
            className={`w-full bg-transparent border-b-2 text-center text-4xl py-2 outline-none placeholder:text-slate-300 font-bold text-black transition-colors ${error ? 'border-red-500' : 'border-[#ef4a2c]'}`}
          />
          {error && (
            <div className="absolute left-0 right-0 -bottom-8 animate-bounce">
              <span className="text-red-600 text-[10px] font-black uppercase tracking-tighter bg-red-50 px-3 py-1 rounded-full shadow-sm border border-red-100">
                ⚠️ {error}
              </span>
            </div>
          )}
        </div>

        <div className="mt-12">
          <button
            onClick={handleCalculate}
            className="bg-[#ef4a2c] text-white text-xl font-black py-4 px-12 rounded-full shadow-lg active:scale-95 transition-all tracking-widest uppercase hover:brightness-110"
          >
            {t.calculate}
          </button>
        </div>
      </div>

      <div className="text-center mt-8">
        <h3 className="text-[#333] text-sm font-bold uppercase tracking-widest py-2">{t.result_title}</h3>
      </div>

      <div className="space-y-5">
        <div className="bg-[#efe9f4] rounded-[1.5rem] p-5 shadow-md text-center border border-white/60 transition-all">
          <h4 className="text-[#ef4a2c] text-xs font-bold uppercase mb-1 tracking-wide">{t.target_acid}</h4>
          <p className="text-[#333] text-xl font-black">
            {results ? `${results.target.cm.toFixed(1)} cm | ${results.target.kg} kg` : "-- cm | -- kg"}
          </p>
        </div>

        <div className="bg-[#efe9f4] rounded-[1.5rem] p-5 shadow-md text-center border border-white/60 transition-all">
          <h4 className="text-[#ef4a2c] text-xs font-bold uppercase mb-1 tracking-wide">{t.pump_acid}</h4>
          <p className="text-[#333] text-xl font-black">
            {results ? `${results.acid.cm.toFixed(1)} cm | ${results.acid.kg} kg` : "-- cm | -- kg"}
          </p>
        </div>

        <div className="bg-[#efe9f4] rounded-[1.5rem] p-5 shadow-md text-center border border-white/60 transition-all">
          <h4 className="text-[#00a651] text-xs font-bold uppercase mb-1 tracking-wide">{t.pump_water}</h4>
          <p className="text-[#333] text-xl font-black">
            {results ? `${results.water.cm.toFixed(1)} cm | ${results.water.kg} kg` : "-- cm | -- kg"}
          </p>
        </div>
      </div>
    </div>
  );
};

export default Calculator;
